#!/system/bin/sh
# Shopee Auto-Spoof - full fingerprint at service stage (property writes are
# clean here; writes at post-fs-data can corrupt context-defined props).
# Runs after boot_completed so SystemUI/launcher are already up.
MODDIR=${0%/*}
PROFILE="pixel5"
[ -f "$MODDIR/profile" ] && PROFILE=$(cat "$MODDIR/profile" | tr -d ' \n')

while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
sleep 10

# cpuinfo bind again (late) + common anti-emu
[ -f "$MODDIR/fake_cpuinfo" ] && mount --bind "$MODDIR/fake_cpuinfo" /proc/cpuinfo 2>/dev/null
resetprop -n ro.kernel.qemu 0
resetprop -n ro.hardware qcom

case "$PROFILE" in
tecno)
    # Profile from the GUI's manual spoof (shopee_bypass_qt.step_manual_spoof).
    resetprop -n ro.product.model "TECNO BD4"
    resetprop -n ro.product.brand "TECNO"
    resetprop -n ro.product.manufacturer "TECNO MOBILE LIMITED"
    resetprop -n ro.product.device "TECNO-BD4"
    resetprop -n ro.product.name "BD4-OP"
    resetprop -n ro.build.product "BD4-OP"
    resetprop -n ro.build.fingerprint "TECNO/BD4-OP/TECNO-BD4:14/UP1A.231005.007/173010:user/release-keys"
    resetprop -n ro.build.description "TECNO-BD4-OP 14 UP1A.231005.007 173010 release-keys"
    ;;
*)
    # Pixel 5 (redfin) - real certified factory fingerprint
    # (gm-stuffs/google_redfin_dump, redfin-user-14-UP1A.231005.007-10754064).
    # Coherent with fake_cpuinfo: Pixel 5 = Snapdragon 765G = SM7250.
    FP="google/redfin/redfin:14/UP1A.231005.007/10754064:user/release-keys"
    resetprop -n ro.build.fingerprint "$FP"
    resetprop -n ro.build.description "redfin-user 14 UP1A.231005.007 10754064 release-keys"
    resetprop -n ro.build.id "UP1A.231005.007"
    resetprop -n ro.build.display.id "UP1A.231005.007"
    resetprop -n ro.product.model "Pixel 5"
    resetprop -n ro.product.brand "google"
    resetprop -n ro.product.manufacturer "Google"
    resetprop -n ro.product.device "redfin"
    resetprop -n ro.product.name "redfin"
    resetprop -n ro.product.board "redfin"
    resetprop -n ro.build.product "redfin"
    resetprop -n ro.product.first_api_level "30"
    resetprop -n ro.board.platform "lito"
    ;;
esac

# Shared coherence props (both profiles).
resetprop -n ro.build.type "user"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.build.version.security_patch "2023-10-05"
resetprop -n ro.product.cpu.abi "arm64-v8a"
resetprop -n ro.product.cpu.abilist "arm64-v8a,armeabi-v7a,armeabi"
resetprop -n ro.product.cpu.abilist64 "arm64-v8a"
resetprop -n ro.product.cpu.abilist32 "armeabi-v7a,armeabi"

echo "autospoof profile=$PROFILE applied: $(getprop ro.build.fingerprint)" > /cache/shopee_autospoof.log
