#!/system/bin/sh
# Shopee Auto-Spoof - early kernel-level anti-emu (safe subset: app-visible
# build props are set at service stage instead, to avoid init boot-loops).
MODDIR=${0%/*}

resetprop -n ro.kernel.qemu 0
resetprop -n ro.kernel.qemu.gles 0
resetprop -n ro.hardware qcom
resetprop -n ro.boot.hardware qcom
resetprop -n ro.boot.selinux enforcing

# /proc/cpuinfo is what native anti-emu checks (libshpssdk) read first.
if [ -f "$MODDIR/fake_cpuinfo" ]; then
    mount --bind "$MODDIR/fake_cpuinfo" /proc/cpuinfo 2>/dev/null
fi
